# KETUX Kakeibo v5 — Stage 3: Data & Reporting

Stage 3 adds the reporting/data layer without changing the authoritative accounting model.

## Added
- Period report snapshot: assets, income, expense, net, income/expense by account, trial balance.
- Print-friendly report with browser Print / Save as PDF flow.
- Journal CSV export.
- Trial Balance CSV export.
- Data screen separates Reports & Export from Backup/Restore.
- Backup version advanced to `5.4-stage3`.

## Integrity rules
- Reports are generated from the deterministic accounting engine.
- Historical source database remains unchanged.
- CSV/print outputs are derived views, not new accounting data.
- Backup/Restore remains separate from future Import workflow.

## Validation
- source database invariants: PASS
- integrated engine tests: PASS
- engine.js syntax: PASS
- inline UI JavaScript syntax: PASS
