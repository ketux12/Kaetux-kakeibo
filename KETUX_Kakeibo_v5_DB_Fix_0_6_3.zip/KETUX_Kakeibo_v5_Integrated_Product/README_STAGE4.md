# KETUX Kakeibo v5 — Stage 4: Import & AI

Stage 4 adds a controlled ingestion layer without bypassing the deterministic accounting engine.

## Import
- CSV import with column mapping.
- XLSX import using the first worksheet, parsed locally in the browser/WebView; no external API is required.
- Mapping fields: date, time, description, amount, type, wallet, category/account.
- Automatic guesses are only defaults and must be reviewed.
- Imported rows are stored as `Perlu dicek` drafts first.
- Possible duplicate detection uses date + amount + wallet + description + type/account fingerprint.
- Duplicate warnings never silently delete or overwrite anything.
- Cut-off date marks older rows as `HISTORIS`; these are blocked from posting unless the user explicitly acknowledges importing them into the active period.
- No automatic opening-balance adjustment is created from an imported historical row.

## AI natural-language draft
- Local parser accepts common Indonesian transaction phrases, amounts (`Rp`, `k`, `ribu`), wallet hints, and basic category hints.
- AI output is always a draft with source `AI`, confidence, and assumptions.
- AI cannot post directly. The user must review and confirm the draft.
- After confirmation, the draft goes through the same `confirmImportDraft` → `post` accounting path as imported/manual transactions.

## Audit/source labels
- Manual: `User input`
- Template: existing template workflow
- AI: `AI`
- Import: `Import`

## Historical source integrity
The September source database remains unchanged. Stage 4 adds user-state drafts and does not rewrite authoritative source journals.

## Validation
- `python3 tests/test_database.py` → PASS
- `node tests/test_engine.js` → PASS
- `node --check engine.js` → PASS
- inline UI JavaScript syntax → PASS
