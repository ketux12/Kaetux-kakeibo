# KETUX Kakeibo v5 — Stage 7 Security & Reliability

Stage 7 hardens the personal-finance MVP without changing the authoritative September source database.

## Security
- Optional device PIN, 6–12 digits.
- PIN is stored as a SHA-256 hash, never as plaintext.
- Auto-lock at 1/5/15 minutes, requiring PIN to be enabled.
- Locks when the app becomes hidden while security is enabled.
- Security event log records lock, unlock, failed unlock, PIN changes, and restore.
- Backup JSON deliberately excludes the device PIN/hash. Restore keeps the PIN configuration already present on the device.
- Backup is **not encrypted**; the UI warns the user to store it securely.

## Reliability
- Integrity check validates posted journal balance, known accounts, known periods, and duplicate IDs where IDs exist.
- Historical source journals without IDs are accepted; they are authoritative source records.
- Existing reconciliation/pending rules remain intact.
- Correction and audit trail remain append-only; original transactions are not silently deleted.

## Biometric status
The web MVP does **not** pretend that Android biometric authentication is available. `nativeBiometricReady` is explicitly false. A native Android biometric bridge belongs in the production Android shell stage.

## Validation
- Source database invariants: PASS
- Integrated engine tests: PASS
- Stage 4 import/AI tests: PASS
- Stage 5 intelligence tests: PASS
- Stage 6 personal finance tests: PASS
- Stage 7 security/reliability tests: PASS
- engine.js syntax: PASS
- inline UI JavaScript syntax: PASS
