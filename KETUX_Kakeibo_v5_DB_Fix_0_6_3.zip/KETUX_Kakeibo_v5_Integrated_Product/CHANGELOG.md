# Changelog

## 0.6.3 - Database v5 + Icon
- Database schema 5.0: jurnal September (18-30) dan Oktober (1-5) dipecah per transaksi, bukan gabungan harian (171 jurnal).
- Transaksi 1-5 Oktober ditambahkan; saldo resmi 5 Okt: Cash 28.000, DANA 0, Buffer 150.000, total 178.000.
- Pending reconciliation Rp170.000 selesai: pendapatan game 3 Okt masuk DANA, bukan Cash.
- Hibah keluarga dicatat sebagai pendapatan lain (405); pinjaman saudara sebagai liabilitas (201).
- Ikon baru: K utuh di atas latar hijau gelap, foreground diperkecil agar aman di launcher.

## 0.5.1 — Integrated Product
- Integrated deterministic accounting engine into KETUX v5 UI.
- Added opening-balance-aware ledger and trial balance.
- Added journal validation and closed-period posting guard.
- Added persistent user journal state in localStorage.
- Added audit/reconciliation view, journal, ledger, and period control.
- Added income/expense/category reports from actual journal data.
- Kept Sep 2026 source data and Oct 2026 pending reconciliation separate.
- Added device transaction time + creation timestamp.

## v5.2 Stage 1 — Daily Foundation
- Added personal Settings: Wants %, Buffer %, optional game stop-loss/time, AI tone, date format, auto-lock preference.
- Added quick transaction templates and one-tap template posting.
- Added daily closing/check screen for Cash, DANA, and Buffer against system balances.
- Added JSON Backup/Restore with compatibility validation.
- Added Home labels "Tercatat" / "Perlu dicek" for user-facing status; accounting terminology remains in Audit.
- Added Data and Settings entry points.
- Added persistent local state fields for settings, templates, and day checks.
- Source accounting engine and September/October baseline preserved.

## v5.3 — Stage 2 Daily Power
- Added atomic Game Session posting for 401/501 through DANA.
- Added Transfer + Admin workflow with 504.
- Added correction/reversal/replacement audit trail for user-entered ordinary transactions.
- Added activity search and income/expense filtering.
- Added repeat-last transaction prefill.
- Added daily Wants/Buffer/game monitoring and stop-loss warning without inventing a historical rule.

## v5 Stage 3 — Data & Reporting
- Added report snapshot API.
- Added journal CSV export.
- Added trial-balance CSV export.
- Added print-friendly financial report / Save as PDF flow.
- Separated Reports & Export from Backup/Restore in Data tools.
- Advanced backup version marker to 5.4-stage3.

## v5.5-stage4 — Import & AI
- Added controlled CSV/XLSX import with mapping and review queue.
- Added local XLSX first-sheet parser for offline-capable WebView use.
- Imported rows enter `Perlu dicek`; they never post automatically.
- Added possible-duplicate fingerprint detection.
- Added cut-off handling for historical imports.
- Added local natural-language AI draft parser with confidence/assumptions.
- AI drafts require explicit user confirmation before posting.
- Added `source: Import` and `source: AI` audit labels.
- Backup version advanced to `5.5-stage4`.

## v5.6-stage5 — Intelligence
- Added deterministic financial intelligence from accounting engine data.
- Added configurable Wants, Buffer, Game and Admin pattern checks.
- Added rolling 7-day Weekly Reflection.
- Added advisor snapshot with explicit engine-only data disclaimer.
- Added Insights and Reflection entry points to Home/More.

## v5.7-stage6 — Personal Finance Expansion
- Added deterministic Financial Goals / savings targets.
- Goal progress can be derived from real wallet/account balances; goals never create money.
- Added configurable date-range Wants budgets with spent/remaining calculations.
- Added monthly review with Needs/Wants/Game/Admin, Buffer, goals, budget and reconciliation status.
- Added cross-period rolling 7-day reflection.
- Added hard guard preventing Buffer account 103 from directly funding Game capital account 501.
- Backup version advanced to 5.7-stage6.

## v5.8-stage7 — Security & Reliability
- Optional hashed device PIN with auto-lock.
- Security event trail for lock/unlock and security changes.
- Backup excludes device PIN/hash; restore preserves the current device PIN.
- Integrity checker for journal balance, account/period references, and duplicate IDs.
- Explicit native biometric readiness flag; no fake biometric capability in the web MVP.
- Preserved authoritative source journals without IDs.

## v5.9-stage8 — Polish / Production
- State schema normalization and safer local persistence.
- Production diagnostics and recovery-oriented error handling.
- Offline/local-data status indicator.
- Restore strips device PIN credentials.
- Security Center now includes production readiness check.

- v6.0-stage9 — Release Candidate: correction/void hardening, persistent period lifecycle, stronger restore compatibility, next-period UI, integration regression suite.

## v6.0-stage10 — Device Acceptance / APK Release Candidate
- Android shell hardened for local-first WebView operation.
- WebView state restoration and lifecycle cleanup.
- Reduced file/content access surface.
- Android backup/device-transfer explicitly excluded; app backup remains user-controlled.
- Android release version bumped to 0.6.0 / versionCode 60.
- Added Stage 10 device acceptance checklist.
