# KETUX Kakeibo v5 — Stage 10 Device Acceptance / APK Release Candidate

Stage 10 prepares the Release Candidate for real Android-device acceptance. No accounting model is changed.

## Android shell hardening
- Android version bumped to `0.6.0` / versionCode `60`.
- WebView JavaScript + DOM storage retained because the app is local-first.
- Content access disabled.
- File-to-file universal access disabled.
- Zoom disabled for a controlled mobile UI.
- WebView state restoration added for activity recreation.
- WebView lifecycle cleanup added.
- Android backup/device-transfer exclusion added because KETUX already has an explicit Backup/Restore workflow.

## Acceptance scope
On the target Android 11 Oppo A54, verify:
1. first launch and bundled September source data
2. Home dashboard values
3. manual input + timestamp
4. quick template / repeat last
5. Game Session and Transfer + Admin
6. correction / audit trail
7. import CSV/XLSX + duplicate review
8. AI draft + explicit confirmation
9. Goals / Wants Budget / Monthly Review
10. PIN + auto-lock
11. backup / restore (PIN must not be restored)
12. print/save-PDF flow where supported by WebView
13. period control and close blocking while reconciliation is pending
14. offline/local persistence after app restart
15. rotation/background/foreground recovery

## Explicit acceptance rules
- September remains authoritative and immutable.
- Oct 2–4 unresolved reconciliation remains `Perlu dicek`.
- The Oct 4 checkpoint is not silently promoted to official ledger.
- Stop-loss remains unset until the user chooses a rule.
- No feature may claim biometric support until native biometric code exists.

## Build
This package is build-ready for the existing Android/Gradle/Colab pipeline. A real APK still requires an Android SDK build environment and device installation test.
