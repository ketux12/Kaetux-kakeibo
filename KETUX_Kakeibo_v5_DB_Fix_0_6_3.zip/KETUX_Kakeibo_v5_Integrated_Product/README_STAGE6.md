# KETUX Kakeibo v5.7 — Stage 6 Personal Finance Expansion

Stage 6 extends the deterministic accounting product with personal-finance planning without inventing money or rewriting historical source data.

## Added
- Financial Goals / savings targets
  - target amount + deadline
  - optional linked wallet/account
  - progress is derived from the real ledger balance of the linked wallet
  - goal records never create accounting transactions
- Proper Wants Budget
  - explicit date-range budget
  - spent / remaining derived from account 503
  - fallback to the configured Wants percentage when no explicit budget exists
  - Game remains account 501 and is not double-counted as Wants
- Buffer protection
  - account 103 cannot directly fund account 501 game capital
  - user must move funds to an operational wallet first
- Monthly Review
  - income / expense / net
  - Needs / Wants / Game / Admin
  - Wants ratio and Game exposure
  - Wants budget status
  - Buffer snapshot
  - goal progress
  - reconciliation status
  - reflection questions
- True rolling 7-day reflection across period boundaries
  - uses posted journals by date rather than restricting the calculation to one period ID

## Integrity principles
- September source database remains authoritative.
- Pending October reconciliation remains pending; it is not silently converted into official ledger entries.
- Stop-loss remains unset until the user chooses a value.
- Goals and budgets are planning metadata; they do not fabricate cash or assets.
- Accounting engine remains the source of numeric truth.

## Validation
- source database invariants: PASS
- integrated engine tests: PASS
- Stage 4 import/AI tests: PASS
- Stage 5 intelligence tests: PASS
- Stage 6 personal finance expansion tests: PASS
- engine.js syntax: PASS
- inline UI JavaScript syntax: PASS
