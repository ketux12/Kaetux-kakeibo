# KETUX Kakeibo v5.2 — Stage 1

Stage 1 focuses on daily speed and data safety without changing the accounting baseline.

## Included
- Settings: Wants 40% default, Buffer 10% default, optional game stop-loss/time, AI tone (default Tegas), display and auto-lock preferences.
- Quick templates and one-tap posting.
- Daily closing: compare system Cash/DANA/Buffer with physical balances and record differences.
- Backup/Restore: JSON backup of user state plus database snapshot; restore validates compatibility.
- User-facing status wording: Tercatat / Perlu dicek; accounting terms remain available in Audit.

## Important
The game stop-loss is intentionally unset by default because the source reports contained conflicting historical limits. The user must choose it in Settings.
