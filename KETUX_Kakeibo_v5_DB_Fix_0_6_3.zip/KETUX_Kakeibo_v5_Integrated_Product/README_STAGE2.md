# KETUX Kakeibo v5 — Stage 2: Daily Power

Stage 2 builds on Stage 1 without changing the authoritative September database.

## Added
- Game Session: one-screen input for gross game result + game capital; posts 401 and 501 atomically through DANA/QRIS.
- Transfer + Admin: Cash/DANA/Buffer transfer and optional 504 admin fee in one journal.
- Correction: user-entered transactions can be corrected by reversal + replacement; original is retained in audit trail.
- Activity search/filter: search by description, source, date and filter income/expense.
- Repeat last / Ulangi: prefills the input form from the latest ordinary transaction.
- Daily Kakeibo monitor: Wants spending, configurable Wants budget, Buffer suggestion, and configurable game stop-loss warning.
- Stop-loss remains unset by default because the historical source contains conflicting rules; the app does not invent one.
- Daily close remains available for wallet reconciliation.

## Accounting rules
- Game Session uses account 401 Pendapatan Game (Bruto) and 501 Beban Modal Game.
- Transfer is asset-to-asset; admin is 504 Beban Administrasi Transaksi.
- Corrections never rewrite the original journal; they create reversal + replacement entries.
- AI is not involved in posting calculations.

## Validation
- source database invariants: PASS
- integrated engine tests: PASS
- JavaScript syntax checks: PASS
