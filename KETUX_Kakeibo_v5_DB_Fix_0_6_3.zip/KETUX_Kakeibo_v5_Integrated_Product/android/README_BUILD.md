# Build KETUX Kakeibo v5

Use Java 17, Android SDK 35, Build Tools 35.0.0, Gradle 8.10.2.

For phone-only workflow, this project is intended to be passed to a Google Colab builder later.

Before release signing, create/persist a KETUX release keystore and reuse it for every future update.
