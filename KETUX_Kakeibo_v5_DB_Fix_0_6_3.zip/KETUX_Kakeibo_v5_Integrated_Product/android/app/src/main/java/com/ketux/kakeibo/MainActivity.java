package com.ketux.kakeibo;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebResourceResponse;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.MimeTypeMap;

import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String ASSET_PREFIX = "/assets/";
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);

        // Keep file access hardened. The app is served through the HTTPS virtual
        // asset origin below, so it does not need direct file:// access.
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);

        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(0x00000000);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {
                return serveAsset(request.getUrl().getHost(), request.getUrl().getPath());
            }

            @Override
            @SuppressWarnings("deprecation")
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                android.net.Uri uri = android.net.Uri.parse(url);
                return serveAsset(uri.getHost(), uri.getPath());
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        }
    }

    private WebResourceResponse serveAsset(String host, String path) {
        if (!APP_HOST.equalsIgnoreCase(host) || path == null || !path.startsWith(ASSET_PREFIX)) {
            return null;
        }

        String assetPath = path.substring(ASSET_PREFIX.length());
        if (assetPath.isEmpty() || assetPath.contains("..")) {
            return null;
        }

        try {
            InputStream input = getAssets().open(assetPath);
            String mime = mimeType(assetPath);
            String encoding = isTextAsset(mime) ? "UTF-8" : null;
            return new WebResourceResponse(mime, encoding, input);
        } catch (Exception ignored) {
            return null;
        }
    }

    private String mimeType(String assetPath) {
        String extension = "";
        int dot = assetPath.lastIndexOf('.');
        if (dot >= 0 && dot < assetPath.length() - 1) {
            extension = assetPath.substring(dot + 1).toLowerCase(Locale.US);
        }

        switch (extension) {
            case "html":
            case "htm":
                return "text/html";
            case "js":
                return "application/javascript";
            case "css":
                return "text/css";
            case "json":
                return "application/json";
            case "svg":
                return "image/svg+xml";
            case "png":
                return "image/png";
            case "jpg":
            case "jpeg":
                return "image/jpeg";
            case "webp":
                return "image/webp";
            case "gif":
                return "image/gif";
            case "ico":
                return "image/x-icon";
            case "txt":
                return "text/plain";
            default:
                String guessed = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
                return guessed != null ? guessed : "application/octet-stream";
        }
    }

    private boolean isTextAsset(String mime) {
        return mime != null && (
                mime.startsWith("text/") ||
                mime.contains("javascript") ||
                mime.contains("json") ||
                mime.contains("xml")
        );
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) {
            webView.saveState(outState);
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
