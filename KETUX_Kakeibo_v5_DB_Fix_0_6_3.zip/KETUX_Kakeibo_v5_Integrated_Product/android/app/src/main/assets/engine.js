/* KETUX Kakeibo v5.0 — deterministic accounting engine */
(function(){
  const KEY='ketux_v5_state_v1';
  const STATE_VERSION=8;
  window.KETUX={};
  const clone=o=>JSON.parse(JSON.stringify(o));
  function loadState(){
    const raw=localStorage.getItem(KEY);
    if(!raw) return {posted:[], pending:[], periodOverrides:{}, settings:{wantsPct:40, bufferPct:10, stopLoss:null, stopTime:null, aiTone:'Tegas', dateFormat:'DD/MM/YYYY', autoLockMinutes:0, pinEnabled:false, pinHash:null}, templates:[], dayChecks:[], corrections:[],importDrafts:[],goals:[],budgets:[],auditTrail:[],securityEvents:[]};
    try{return Object.assign({posted:[],pending:[],periodOverrides:{},settings:{wantsPct:40,bufferPct:10,stopLoss:null,stopTime:null,aiTone:'Tegas',dateFormat:'DD/MM/YYYY',autoLockMinutes:0,pinEnabled:false,pinHash:null},templates:[],dayChecks:[],corrections:[],importDrafts:[],goals:[],budgets:[],auditTrail:[],securityEvents:[]},JSON.parse(raw));}catch(e){return {posted:[],pending:[],periodOverrides:{},settings:{wantsPct:40,bufferPct:10,stopLoss:null,stopTime:null,aiTone:'Tegas',dateFormat:'DD/MM/YYYY',autoLockMinutes:0,pinEnabled:false,pinHash:null},templates:[],dayChecks:[],corrections:[],importDrafts:[],goals:[],budgets:[],auditTrail:[],securityEvents:[]};}
  }
  let state=loadState();
  let db=null;
  function save(){
    state.schema_version=STATE_VERSION;
    try{localStorage.setItem(KEY,JSON.stringify(state));return true;}
    catch(e){throw new Error('Data lokal tidak dapat disimpan. Penyimpanan perangkat mungkin penuh atau dibatasi. Tidak ada perubahan yang boleh dianggap tersimpan.');}
  }
  function normalizeState(x){
    const d={posted:[],pending:[],periodOverrides:{},current_period_id:null,settings:{wantsPct:40,bufferPct:10,stopLoss:null,stopTime:null,aiTone:'Tegas',dateFormat:'DD/MM/YYYY',autoLockMinutes:0,pinEnabled:false,pinHash:null},templates:[],dayChecks:[],corrections:[],importDrafts:[],goals:[],budgets:[],auditTrail:[],securityEvents:[],schema_version:STATE_VERSION};
    const o=Object.assign(d,x||{}); o.settings=Object.assign(d.settings,o.settings||{});
    ['posted','pending','periodOverrides','templates','dayChecks','corrections','importDrafts','goals','budgets','auditTrail','securityEvents'].forEach(k=>{if(o[k]==null)o[k]=d[k];});
    o.schema_version=STATE_VERSION; return o;
  }
  const accounts=()=>db?.accounts||[];
  const acc=c=>accounts().find(a=>a.code===String(c));
  const accountName=c=>acc(c)?.name||String(c);
  const accountType=c=>acc(c)?.type||'';
  function periods(){
    const base=clone(db?.period_management?.periods||[]);
    const ov=state.periodOverrides||{};
    const merged=base.map(p=>ov[p.id]?Object.assign(p,ov[p.id]):p);
    Object.keys(ov).filter(id=>!merged.some(p=>p.id===id)).forEach(id=>merged.push(clone(ov[id])));
    return merged;
  }
  const period=id=>periods().find(p=>p.id===id);
  const currentPeriod=()=>period(state.current_period_id||db?.period_management?.current_period_id)||periods().find(p=>p.status==='open');
  const allPosted=()=>{
    const voided=new Set((state.corrections||[]).map(c=>c.original_id).filter(Boolean));
    return [...(db?.journals||[]),...state.posted].filter(j=>j.status==='posted'&&!voided.has(j.id));
  };
  const allPending=()=>[...(db?.pending_reconciliation||[]),...state.pending];
  function parseDate(s){return s||'9999-12-31'}
  function openingFor(pid){
    const p=period(pid); if(!p)return {assets:{101:0,102:0,103:0},equity:0};
    return {assets:Object.assign({101:0,102:0,103:0},p.opening_assets||{}),equity:Number(p.opening_equity||0)};
  }
  function journalBalance(j){
    const d=(j.lines||[]).reduce((s,l)=>s+Number(l.debit||0),0);
    const c=(j.lines||[]).reduce((s,l)=>s+Number(l.credit||0),0);
    return {debit:d,credit:c,balanced:d===c&&d>0};
  }
  function journals(pid,until){return allPosted().filter(j=>(j.period_id||'2026-09')===pid && (!until||parseDate(j.date)<=parseDate(until)));}
  function ledger(pid,until){
    const b={}; accounts().forEach(a=>b[a.code]=0);
    const o=openingFor(pid); Object.entries(o.assets).forEach(([c,v])=>b[c]=Number(v||0));
    if(o.equity)b['301']=-(Number(o.equity)||0); // credit-normal equity represented as debit-credit net
    journals(pid,until).forEach(j=>(j.lines||[]).forEach(l=>{b[l.account]=(b[l.account]||0)+Number(l.debit||0)-Number(l.credit||0);}));
    return b;
  }
  function assetBalances(pid,until){const b=ledger(pid,until);return {101:b[101]||0,102:b[102]||0,103:b[103]||0,total:(b[101]||0)+(b[102]||0)+(b[103]||0)};}
  function incomeExpense(pid,until){
    let income=0,expense=0; const incomeBy={},expenseBy={};
    journals(pid,until).forEach(j=>(j.lines||[]).forEach(l=>{const t=accountType(l.account); if(t==='income'||t==='income_extension'){const v=Number(l.credit||0)-Number(l.debit||0); income+=v; incomeBy[l.account]=(incomeBy[l.account]||0)+v;} if(t==='expense'){const v=Number(l.debit||0)-Number(l.credit||0); expense+=v; expenseBy[l.account]=(expenseBy[l.account]||0)+v;}}));
    return {income,expense,net:income-expense,incomeBy,expenseBy};
  }
  function cashflow(pid,until){
    const map={}; const o=openingFor(pid); let prev={...o.assets};
    journals(pid,until).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).forEach(j=>{
      const date=j.date; if(!map[date])map[date]={date,income:0,expense:0,assetDelta:0};
      let dAssets=0;
      (j.lines||[]).forEach(l=>{if(['101','102','103'].includes(String(l.account))) dAssets+=Number(l.debit||0)-Number(l.credit||0);});
      map[date].assetDelta+=dAssets;
      const ie=incomeExpenseSingle(j); map[date].income+=ie.income; map[date].expense+=ie.expense;
    });
    return Object.values(map).sort((a,b)=>a.date.localeCompare(b.date));
  }
  function incomeExpenseSingle(j){let income=0,expense=0;(j.lines||[]).forEach(l=>{const t=accountType(l.account);if(t==='income'||t==='income_extension')income+=Number(l.credit||0)-Number(l.debit||0);if(t==='expense')expense+=Number(l.debit||0)-Number(l.credit||0)});return {income,expense};}
  function trial(pid,until){
    const b=ledger(pid,until); let debit=0,credit=0; const rows=[];
    accounts().forEach(a=>{const n=b[a.code]||0; let dr=0,cr=0;if(n>=0)dr=n;else cr=-n;debit+=dr;credit+=cr;rows.push({code:a.code,name:a.name,type:a.type,debit:dr,credit:cr,balance:n});});
    return {rows,debit,credit,balanced:debit===credit};
  }
  function auditTrail(){return state.auditTrail||[];}
  function securityEvents(){return state.securityEvents||[];}
  function addAudit(action,detail,ref){state.auditTrail=state.auditTrail||[];state.auditTrail.push({id:'a_'+Date.now()+'_'+Math.random().toString(36).slice(2,7),at:new Date().toISOString(),action,detail:detail||'',ref:ref||null});if(state.auditTrail.length>1000)state.auditTrail=state.auditTrail.slice(-1000);}
  function addSecurityEvent(action,detail){state.securityEvents=state.securityEvents||[];state.securityEvents.push({at:new Date().toISOString(),action,detail:detail||''});if(state.securityEvents.length>200)state.securityEvents=state.securityEvents.slice(-200);save();}
  function integrityCheck(){
    const issues=[]; const seen=new Set();
    allPosted().forEach(j=>{if(j.id){if(seen.has(j.id))issues.push('Duplicate journal ID: '+j.id);else seen.add(j.id);}const b=journalBalance(j);if(!b.balanced)issues.push('Journal tidak balanced: '+j.id);(j.lines||[]).forEach(l=>{if(!acc(l.account))issues.push('Akun tidak dikenal '+l.account+' pada '+j.id);});});
    const pids=periods().map(x=>x.id); allPosted().forEach(j=>{if(!pids.includes(j.period_id))issues.push('Periode tidak dikenal: '+j.period_id);});
    return {ok:issues.length===0,issues,checked_at:new Date().toISOString(),journalCount:allPosted().length,pendingCount:allPending().length};
  }
  function securityStatus(){const s=settings();return {pinEnabled:!!s.pinEnabled,autoLockMinutes:Number(s.autoLockMinutes||0),nativeBiometricReady:false,securityEvents:securityEvents().slice(-20)};}
  function setSecurityConfig(patch){state.settings=Object.assign({},state.settings||{},patch);addAudit('SECURITY_SETTINGS_CHANGED','Pengaturan keamanan diperbarui');save();return securityStatus();}
  function recordSecurityEvent(action,detail){addSecurityEvent(action,detail);}
  function validateJournal(j){
    const x=journalBalance(j); if(!x.balanced)return {ok:false,error:'Debit dan credit harus sama dan lebih dari nol.'};
    if(!j.date||!j.period_id)return {ok:false,error:'Tanggal dan periode wajib ada.'};
    const p=period(j.period_id); if(!p)return {ok:false,error:'Periode tidak ditemukan.'};
    if(p.status==='closed')return {ok:false,error:'Periode sudah CLOSED. Tidak boleh posting transaksi baru.'};
    for(const l of j.lines||[])if(!acc(l.account))return {ok:false,error:'Akun '+l.account+' tidak ditemukan.'};
    return {ok:true};
  }
  function post(j){
    j.status='posted'; j.id=j.id||('j_'+Date.now()+'_'+Math.random().toString(36).slice(2,8)); j.source=j.source||'User input'; j.created_at=j.created_at||new Date().toISOString();
    const v=validateJournal(j); if(!v.ok)throw new Error(v.error);
    if((j.lines||[]).some(l=>String(l.account)==='501'&&Number(l.debit||0)>0) && (j.lines||[]).some(l=>String(l.account)==='103'&&Number(l.credit||0)>0)) throw new Error('Buffer tidak boleh digunakan sebagai modal game. Pindahkan dana ke wallet operasional terlebih dahulu.');
    state.posted.push(clone(j)); addAudit('POST',j.description,j.id); save(); return j;
  }
  function addPending(p){state.pending.push(clone(p));addAudit('PENDING_RECONCILIATION',p.description||'Pending reconciliation',p.id||null);save();}
  function postGameSession(x){
    const amount=Number(x.amount||0), capital=Number(x.capital||amount);
    if(amount<=0||capital<0)throw new Error('Hasil game dan modal harus valid.');
    const p=period(x.period_id||currentPeriod()?.id); if(!p)throw new Error('Periode tidak ditemukan.');
    const d=x.date,t=x.time||'00:00';
    const j={date:d,time:t,transaction_at:`${d}T${t}:00`,created_at:new Date().toISOString(),description:x.description||'Sesi game',period_id:p.id,status:'posted',source:'Game Session',lines:[{account:'102',debit:amount,credit:0},{account:'401',debit:0,credit:amount},{account:'501',debit:capital,credit:0},{account:'102',debit:0,credit:capital}]};
    // Net-zero game session is represented as one atomic balanced journal: gross result and capital are both DANA.
    if(capital===0){ j.lines=j.lines.filter(l=>!(l.account==='501'&&l.debit===0)); }
    return post(j);
  }
  function postTransferWithAdmin(x){
    const amount=Number(x.amount||0),admin=Number(x.admin||0),from=String(x.from),to=String(x.to);
    if(amount<=0||!from||!to||from===to)throw new Error('Transfer tidak valid.');
    if(admin<0)throw new Error('Admin tidak boleh negatif.');
    const total=amount+admin;
    const lines=[{account:to,debit:amount,credit:0},{account:from,debit:0,credit:total}];
    if(admin>0)lines.push({account:'504',debit:admin,credit:0});
    return post({date:x.date,time:x.time||'00:00',transaction_at:`${x.date}T${x.time||'00:00'}:00`,created_at:new Date().toISOString(),description:x.description||'Transfer wallet',period_id:x.period_id||currentPeriod()?.id,status:'posted',source:'Transfer · admin',lines});
  }
  function correctionRecords(){return state.corrections||[];}
  function correctJournal(id,replacement){
    const original=[...(db?.journals||[]),...state.posted].find(j=>(j.id===id||j.entry_id===id)&&j.status!=='voided'&&!((state.corrections||[]).some(c=>c.original_id===j.id))); if(!original)throw new Error('Transaksi tidak ditemukan.');
    if(original.status==='voided')throw new Error('Transaksi sudah dikoreksi/dibatalkan.');
    if(period(original.period_id)?.status==='closed')throw new Error('Transaksi periode CLOSED tidak dapat dikoreksi langsung. Buat jurnal penyesuaian pada periode terbuka.');
    const reversal={date:replacement.date||original.date,time:replacement.time||original.time||'00:00',transaction_at:`${replacement.date||original.date}T${replacement.time||original.time||'00:00'}:00`,description:`Koreksi pembalik: ${original.description}`,period_id:original.period_id,status:'posted',source:'Correction · reversal',lines:(original.lines||[]).map(l=>({account:l.account,debit:Number(l.credit||0),credit:Number(l.debit||0)}))};
    post(reversal);
    const repl=Object.assign({},replacement,{period_id:original.period_id,status:'posted',source:'Correction · replacement'});
    post(repl);
    state.corrections.push({id:'corr_'+Date.now(),original_id:id,created_at:new Date().toISOString(),reversal_id:reversal.id,replacement_id:repl.id,reason:replacement.reason||'Koreksi transaksi'});
    state.posted=state.posted.map(j=>(j.id===original.id||j.entry_id===original.id)?Object.assign({},j,{status:'voided',voided_by:repl.id}):j);
    save(); return repl;
  }
  function searchPosted(q,filter){
    const term=String(q||'').toLowerCase().trim(); let rows=allPosted().filter(j=>j.status==='posted');
    if(term)rows=rows.filter(j=>(j.description+' '+j.source+' '+j.date+' '+(j.time||'')).toLowerCase().includes(term));
    if(filter==='income')rows=rows.filter(j=>(j.lines||[]).some(l=>['income','income_extension'].includes(accountType(l.account))));
    if(filter==='expense')rows=rows.filter(j=>(j.lines||[]).some(l=>accountType(l.account)==='expense'));
    return rows.sort((a,b)=>(b.date+b.time).localeCompare(a.date+a.time));
  }
  function dailyStats(date,pid){
    const js=journals(pid||currentPeriod()?.id,date).filter(j=>j.date===date); let income=0,needs=0,wants=0,game=0;
    js.forEach(j=>(j.lines||[]).forEach(l=>{const t=accountType(l.account),v=Number(l.debit||0)-Number(l.credit||0);if(t==='income'||t==='income_extension')income+=-v;if(l.account==='502')needs+=v;if(l.account==='503')wants+=v;if(l.account==='501')game+=v;}));
    const s=settings(),wantsBudget=Math.round(income*Number(s.wantsPct||0)/100),bufferSuggestion=Math.round(income*Number(s.bufferPct||0)/100),stop=s.stopLoss==null?null:Number(s.stopLoss);
    return {date,income,needs,wants,game,wantsBudget,wantsRemaining:wantsBudget-wants,bufferSuggestion,stopLoss:stop,stopLossRemaining:stop==null?null:stop-game,stopTime:s.stopTime||null};
  }
  function intelligence(pid,until){
    const p=period(pid)||currentPeriod(); if(!p)throw new Error('Periode tidak ditemukan.');
    const u=until||'9999-12-31', ie=incomeExpense(p.id,u), a=assetBalances(p.id,u), s=settings();
    const wants=Number(ie.expenseBy?.['503']||0), needs=Number(ie.expenseBy?.['502']||0), game=Number(ie.expenseBy?.['501']||0), admin=Number(ie.expenseBy?.['504']||0);
    const discretionary=needs+wants+game+admin;
    const wantsPct=discretionary?Math.round(wants/discretionary*1000)/10:0;
    const net=Number(ie.net||0), buffer=Number(a[103]||0), income=Number(ie.income||0);
    const insights=[];
    if(income>0 && net<0) insights.push({type:'risk',title:'Pengeluaran melebihi pemasukan',detail:`Net periode ${net<0?'negatif':''} ${Math.abs(net)}. Fokus pertama adalah menghentikan kebocoran sebelum mengejar target baru.`});
    if(wants>0 && income>0 && wants/income > Number(s.wantsPct||40)/100) insights.push({type:'wants',title:'Wants melewati batas',detail:`Wants ${wantsPct}% dari pengeluaran yang terukur, sementara aturan Wants ${s.wantsPct}%.`});
    if(game>0 && income>0 && game/income >= 0.25) insights.push({type:'game',title:'Eksposur game signifikan',detail:`Beban modal game ${Math.round(game/income*1000)/10}% dari pemasukan periode.`});
    if(buffer===0 && income>0) insights.push({type:'buffer',title:'Buffer belum terbentuk',detail:`Belum ada saldo Buffer pada snapshot ini. Aturan Buffer saat ini ${s.bufferPct}%.`});
    if(buffer>0 && income>0 && buffer/income < Number(s.bufferPct||0)/100) insights.push({type:'buffer',title:'Buffer di bawah aturan',detail:`Buffer ${buffer} dibanding pemasukan ${income}; bandingkan dengan aturan Buffer ${s.bufferPct}%.`});
    if(admin>0 && income>0 && admin/income >= .03) insights.push({type:'admin',title:'Biaya administrasi mulai terasa',detail:`Administrasi ${admin}, sekitar ${Math.round(admin/income*1000)/10}% dari pemasukan.`});
    if(!insights.length) insights.push({type:'ok',title:'Tidak ada alarm utama',detail:'Snapshot ini belum menunjukkan pola yang melewati aturan utama yang tersedia.'});
    return {period:{id:p.id,name:p.name},metrics:{income,expense:ie.expense,net,assets:a.total,cash:a[101],dana:a[102],buffer,wants,needs,game,admin,wantsPct},rules:{wantsPct:Number(s.wantsPct||0),bufferPct:Number(s.bufferPct||0),stopLoss:s.stopLoss,stopTime:s.stopTime},insights};
  }
  function weeklyReflection(pid,endDate){return weeklyReflectionAll(endDate);}
  function advisorSnapshot(pid,until){
    const x=intelligence(pid,until); const tone=settings().aiTone||'Tegas';
    return {tone,disclaimer:'AI advisor hanya menjelaskan data dari accounting engine. Ia tidak menggantikan keputusan pengguna dan tidak mengarang angka.',summary:x.insights.map(i=>i.title+': '+i.detail),metrics:x.metrics};
  }
  function totals(pid,until){const a=assetBalances(pid,until),ie=incomeExpense(pid,until);return {...a,...ie};}
  function closePeriod(pid){
    const p=period(pid); if(!p)throw new Error('Periode tidak ditemukan.');
    if(p.status==='closed')throw new Error('Periode sudah CLOSED.');
    if(allPending().length)throw new Error('Tidak dapat menutup periode: masih ada pending reconciliation.');
    const a=assetBalances(pid,'9999-12-31');
    const closed=Object.assign({},p,{status:'closed',end:p.end||new Date().toISOString().slice(0,10),closing_assets:{101:a[101],102:a[102],103:a[103]},closing_equity:a.total,closing_total:a.total});
    state.periodOverrides=state.periodOverrides||{}; state.periodOverrides[pid]=closed; save(); return closed;
  }
  function createNextPeriod(pid,start){
    const p=period(pid); if(!p||p.status!=='closed')throw new Error('Periode sumber harus CLOSED.');
    const nextStart=start||(()=>{const d=new Date((p.end||p.start)+'T00:00:00');d.setUTCDate(d.getUTCDate()+1);return d.toISOString().slice(0,10)})();
    const id=nextStart.slice(0,7); if(period(id))throw new Error('Periode berikutnya sudah ada.');
    const np={id,name:new Date(nextStart+'T00:00:00Z').toLocaleString('id-ID',{month:'long',year:'numeric'}),start:nextStart,end:null,status:'open',opening_assets:{...p.closing_assets},opening_equity:Number(p.closing_equity||p.closing_total||0),opening_source_period:pid};
    state.periodOverrides=state.periodOverrides||{}; state.periodOverrides[id]=np; state.current_period_id=id; save(); return np;
  }

  function reportSnapshot(pid,until){
    const p=period(pid)||currentPeriod(); if(!p)throw new Error('Periode tidak ditemukan.');
    const u=until||'9999-12-31', a=assetBalances(p.id,u), ie=incomeExpense(p.id,u), tr=trial(p.id,u);
    return {generated_at:new Date().toISOString(),period:{id:p.id,name:p.name,start:p.start,end:p.end,status:p.status},assets:{cash:a[101],dana:a[102],buffer:a[103],total:a.total},income:ie.income,expense:ie.expense,net:ie.net,incomeBy:ie.incomeBy,expenseBy:ie.expenseBy,trialBalance:{debit:tr.debit,credit:tr.credit,balanced:tr.balanced,rows:tr.rows}};
  }
  function exportJournalRows(pid,until){
    return journals(pid,until).sort((a,b)=>(a.date+(a.time||'')).localeCompare(b.date+(b.time||''))).map(j=>({id:j.id,date:j.date,time:j.time||'',period_id:j.period_id,description:j.description||'',source:j.source||'',debit:(j.lines||[]).reduce((s,l)=>s+Number(l.debit||0),0),credit:(j.lines||[]).reduce((s,l)=>s+Number(l.credit||0),0),lines:(j.lines||[]).map(l=>`${l.account} ${accountName(l.account)} D${Number(l.debit||0)} C${Number(l.credit||0)}`).join(' | ')}));
  }
  function csvEscape(v){const s=String(v??'');return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;}
  function toCSV(rows){if(!rows.length)return '';const h=Object.keys(rows[0]);return [h.map(csvEscape).join(','),...rows.map(r=>h.map(k=>csvEscape(r[k])).join(','))].join('\n');}
  function importDrafts(){return state.importDrafts||[];}
  function importFingerprint(x){return [x.date||'',Number(x.amount||0),x.wallet||'',String(x.description||'').trim().toLowerCase(),x.kind||'',x.account||''].join('|');}
  function findDuplicateImport(x){const fp=importFingerprint(x);return [...allPosted(),...allPending(),...importDrafts()].filter(r=>r.fingerprint===fp||importFingerprint(r)===fp);}
  function addImportDrafts(rows,meta){
    const added=[]; const now=new Date().toISOString();
    (rows||[]).forEach((r,i)=>{const x=Object.assign({id:'imp_'+Date.now()+'_'+i+'_'+Math.random().toString(36).slice(2,7),status:'review',source:meta?.source||'Import',created_at:now},r);x.amount=Number(x.amount||0);x.fingerprint=importFingerprint(x);x.duplicate_candidates=findDuplicateImport(x).map(d=>d.id||d.description).filter(Boolean);state.importDrafts.push(x);added.push(x)}); save(); return added;
  }
  function removeImportDraft(id){state.importDrafts=(state.importDrafts||[]).filter(x=>x.id!==id);save();}
  function confirmImportDraft(id,patch){
    const x=(state.importDrafts||[]).find(r=>r.id===id); if(!x)throw new Error('Draft import tidak ditemukan.');
    const v=Object.assign({},x,patch||{}); const amt=Number(v.amount||0); if(!v.date||!amt)throw new Error('Tanggal dan jumlah wajib.');
    const p=period(v.period_id||currentPeriod()?.id); if(!p)throw new Error('Periode tidak ditemukan.'); if(p.status==='closed')throw new Error('Periode sudah CLOSED.');
    const kind=v.kind||'expense'; const account=String(v.account|| (kind==='income'?'402':'502')); const wallet=String(v.wallet||'101');
    if(!acc(account)||!acc(wallet))throw new Error('Akun import tidak valid.');
    const t=v.time||'00:00'; const j={date:v.date,time:t,transaction_at:`${v.date}T${t}:00`,created_at:new Date().toISOString(),description:v.description||'Import transaction',period_id:p.id,status:'posted',source:v.source||'Import',import_id:x.id,lines:kind==='income'?[{account:wallet,debit:amt,credit:0},{account:account,debit:0,credit:amt}]:[{account:account,debit:amt,credit:0},{account:wallet,debit:0,credit:amt}]};
    const dup=findDuplicateImport(v).filter(d=>d.id!==x.id); if(dup.length&&!v.force_duplicate)throw new Error('Transaksi mirip sudah ada. Tandai sebagai duplikat yang memang benar dengan konfirmasi force_duplicate.');
    const posted=post(j); state.importDrafts=state.importDrafts.filter(r=>r.id!==id); save(); return posted;
  }
  function allUnreviewed(){return importDrafts();}
  function aiDraft(text){
    const q=String(text||'').trim(), low=q.toLowerCase();
    const m=q.match(/(?:rp\s*)?([0-9][0-9.,]*)(?:\s*(k|rb|ribu))?/i); let amount=m?Number(m[1].replace(/\./g,'').replace(/,/g,'')):0; if(m&&m[2])amount*=1000;
    let kind=/\b(dapat|terima|menerima|gaji|upah|pendapatan|dibayar|masuk|income|sewa)\b/i.test(low)?'income':'expense';
    let wallet=/dana|qris|qr/i.test(low)?'102':/buffer/i.test(low)?'103':'101';
    let account=kind==='income'?'402':(/rokok|cigarette|kopi|teh|snack|jajan|nongkrong|hiburan/i.test(low)?'503':'502');
    if(/game|modal/i.test(low))account='501'; if(/admin|biaya admin/i.test(low))account='504';
    if(/sosial media|media sosial/i.test(low))account='403'; if(/sewa/i.test(low))account='404'; if(/hibah|pemberian keluarga/i.test(low))account='405';
    if(/game.*(hasil|menang|dapat)|menang.*game/i.test(low))account='401';
    const d=new Date(),date=d.toISOString().slice(0,10),time=d.toTimeString().slice(0,5);
    const confidence=(amount?0.45:0)+(q?0.15:0)+(wallet!=='101'?0.15:0)+(account!=='502'&&account!=='402'?0.2:0);
    return {date,time,amount,description:q,kind,account,wallet,source:'AI',confidence:Math.min(0.95,confidence),assumptions:['Parser AI lokal membuat draft saja; transaksi tidak diposting otomatis.','Kategori/wallet yang tidak eksplisit adalah tebakan awal dan harus dikonfirmasi.']};
  }
  function goals(){return state.goals||[];}
  function addGoal(g){
    const x=Object.assign({id:'goal_'+Date.now()+'_'+Math.random().toString(36).slice(2,6),created_at:new Date().toISOString(),status:'active'},g);
    x.targetAmount=Number(x.targetAmount||0); if(x.targetAmount<=0)throw new Error('Target goal harus lebih dari nol.');
    if(x.sourceAccount&&!acc(x.sourceAccount))throw new Error('Wallet/account goal tidak ditemukan.');
    state.goals=[...(state.goals||[]).filter(v=>v.id!==x.id),x]; save(); return x;
  }
  function removeGoal(id){state.goals=(state.goals||[]).filter(g=>g.id!==id);save();}
  function goalProgress(g,until){
    const u=until||'9999-12-31';
    if(g.sourceAccount){
      // Progress is derived from the latest real ledger balance; the goal itself never creates money.
      const ps=periods().filter(p=>p.start&&p.start<=u).sort((a,b)=>a.start.localeCompare(b.start));
      const lp=ps[ps.length-1]; if(!lp)return 0; const a=assetBalances(lp.id,u); return Math.max(0,Number(a[g.sourceAccount]||0));
    }
    return Math.max(0,Number(g.progressAmount||0));
  }
  function goalSnapshot(until){
    return goals().map(g=>{const progress=goalProgress(g,until);const target=Number(g.targetAmount||0);const pct=target?Math.min(100,Math.round(progress/target*1000)/10):0;return {...g,progress,target,pct,remaining:Math.max(0,target-progress)};});
  }
  function budgets(){return state.budgets||[];}
  function addBudget(b){
    const x=Object.assign({id:'budget_'+Date.now()+'_'+Math.random().toString(36).slice(2,6),created_at:new Date().toISOString(),type:'wants'},b);
    x.amount=Number(x.amount||0); if(x.amount<0)throw new Error('Budget tidak boleh negatif.'); if(!x.startDate||!x.endDate)throw new Error('Rentang budget wajib.');
    state.budgets=[...(state.budgets||[]).filter(v=>v.id!==x.id),x];save();return x;
  }
  function removeBudget(id){state.budgets=(state.budgets||[]).filter(b=>b.id!==id);save();}
  function rangeExpense(start,end,accountCode){
    let spent=0; allPosted().filter(j=>j.status==='posted'&&j.date>=start&&j.date<=end).forEach(j=>(j.lines||[]).forEach(l=>{if(String(l.account)===String(accountCode))spent+=Number(l.debit||0)-Number(l.credit||0);}));
    return spent;
  }
  function wantsBudgetSnapshot(start,end){
    const bs=budgets().filter(b=>b.type==='wants'&&b.startDate<=end&&b.endDate>=start).sort((a,b)=>b.created_at.localeCompare(a.created_at));
    const b=bs[0]||null; const spent=rangeExpense(start,end,'503');
    const amount=b?Number(b.amount||0):Math.round((incomeExpenseForRange(start,end).income||0)*Number(settings().wantsPct||0)/100);
    return {budget:amount,spent,remaining:amount-spent,source:b?'configured':'percentage_rule',start,end,budgetId:b?.id||null};
  }
  function incomeExpenseForRange(start,end){let income=0,expense=0,by={};allPosted().filter(j=>j.status==='posted'&&j.date>=start&&j.date<=end).forEach(j=>(j.lines||[]).forEach(l=>{const t=accountType(l.account);if(t==='income'||t==='income_extension')income+=Number(l.credit||0)-Number(l.debit||0);if(t==='expense'){const v=Number(l.debit||0)-Number(l.credit||0);expense+=v;by[l.account]=(by[l.account]||0)+v;}}));return {income,expense,net:income-expense,expenseBy:by};}
  function monthlyReview(month){
    const m=String(month||new Date().toISOString().slice(0,7)), start=m+'-01', d=new Date(start+'T00:00:00Z'); d.setUTCMonth(d.getUTCMonth()+1); d.setUTCDate(0); const end=d.toISOString().slice(0,10);
    const x=incomeExpenseForRange(start,end), wants=Number(x.expenseBy['503']||0),needs=Number(x.expenseBy['502']||0),game=Number(x.expenseBy['501']||0),admin=Number(x.expenseBy['504']||0), wb=wantsBudgetSnapshot(start,end);
    const buffer=Math.max(0,...periods().map(p=>Number(assetBalances(p,end)[103]||0)));
    return {month:m,start,end,income:x.income,expense:x.expense,net:x.net,needs,wants,game,admin,wantsRatio:x.expense?Math.round(wants/x.expense*1000)/10:0,gameRatio:x.income?Math.round(game/x.income*1000)/10:0,buffer,wantsBudget:wb,goals:goalSnapshot(end),pending:allPending().length,questions:['Apa satu pengeluaran yang paling layak dipertahankan bulan ini?','Apa Wants terbesar yang bisa dipangkas bulan depan?','Apakah modal game masih sesuai risiko yang kamu pilih?','Apakah Buffer bergerak menuju target?']};
  }
  function weeklyReflectionAll(endDate){
    const end=endDate||new Date().toISOString().slice(0,10); const d=new Date(end+'T00:00:00Z'); d.setUTCDate(d.getUTCDate()-6); const start=d.toISOString().slice(0,10); const x=incomeExpenseForRange(start,end), by=x.expenseBy; return {start,end,income:x.income,expense:x.expense,net:x.net,wants:Number(by['503']||0),needs:Number(by['502']||0),game:Number(by['501']||0),questions:['Apa pengeluaran yang paling layak dipertahankan?','Apa Wants yang sebenarnya bisa ditunda?','Apakah keputusan game minggu ini sesuai batas risiko yang kamu pilih?','Apakah Buffer bertambah sesuai niat awal?']};
  }
  function productionDiagnostics(){
    const issues=[];
    if(!db)issues.push('Database belum diinisialisasi.');
    if(!Array.isArray(state.posted)||!Array.isArray(state.pending))issues.push('State transaksi tidak valid.');
    try{if(!localStorage.getItem(KEY))issues.push('State belum tersimpan di perangkat.');}catch(e){issues.push('Local storage tidak tersedia.');}
    const integ=integrityCheck(); if(!integ.ok)issues.push(...integ.issues);
    return {ok:issues.length===0,issues,schema_version:STATE_VERSION,storage_key:KEY,posted:state.posted.length,pending:state.pending.length};
  }
  function resetUserState(){state=normalizeState();save();}
  function settings(){return state.settings;}
  function updateSettings(patch){state.settings=Object.assign({},state.settings||{},patch);save();return state.settings;}
  function templates(){return state.templates||[];}
  function addTemplate(t){const x=Object.assign({id:'tpl_'+Date.now(),created_at:new Date().toISOString()},t);state.templates=[...(state.templates||[]).filter(v=>v.id!==x.id),x];save();return x;}
  function removeTemplate(id){state.templates=(state.templates||[]).filter(t=>t.id!==id);save();}
  function dayChecks(){return state.dayChecks||[];}
  function saveDayCheck(c){const x=Object.assign({created_at:new Date().toISOString()},c);state.dayChecks=[...(state.dayChecks||[]).filter(v=>v.date!==x.date),x];save();return x;}
  function backupPayload(){const u=clone(state);if(u.settings)u.settings.pinHash=null,u.settings.pinEnabled=false;return {backup_version:'6.0-stage9',created_at:new Date().toISOString(),security_note:'PIN perangkat tidak disertakan dalam backup. Backup JSON tidak terenkripsi; simpan di tempat aman.',database:clone(db),user_state:u};}
  function restorePayload(payload){if(!payload||!payload.database||!payload.user_state)throw new Error('File backup tidak valid.');if(payload.database.accounts?.length!==db.accounts?.length)throw new Error('Database backup tidak cocok dengan versi aplikasi ini.');const srcCodes=(payload.database.accounts||[]).map(a=>a.code).join('|');const localCodes=accounts().map(a=>a.code).join('|');if(srcCodes!==localCodes)throw new Error('Struktur akun backup tidak cocok dengan aplikasi ini.');state=normalizeState(clone(payload.user_state));state.settings.pinHash=null;state.settings.pinEnabled=false;save();addSecurityEvent('RESTORE','Backup dipulihkan; PIN perangkat lama tidak ikut dipulihkan.');return state;}
  window.KETUX.init=function(x){db=x; state=loadState(); return db;};
  Object.assign(window.KETUX,{db:()=>db,state:()=>state,settings,updateSettings,templates,addTemplate,removeTemplate,dayChecks,saveDayCheck,correctionRecords,backupPayload,restorePayload,reportSnapshot,exportJournalRows,toCSV,accounts,accountName,accountType,period,currentPeriod,periods,allPosted,allPending,allUnreviewed,openingFor,journalBalance,journals,ledger,assetBalances,incomeExpense,cashflow,trial,validateJournal,post,postGameSession,postTransferWithAdmin,correctJournal,searchPosted,dailyStats,addPending,importDrafts,addImportDrafts,removeImportDraft,confirmImportDraft,aiDraft,intelligence,weeklyReflection,weeklyReflectionAll,advisorSnapshot,auditTrail,securityEvents,securityStatus,setSecurityConfig,recordSecurityEvent,integrityCheck,productionDiagnostics,totals,goals,addGoal,removeGoal,goalProgress,goalSnapshot,budgets,addBudget,removeBudget,wantsBudgetSnapshot,monthlyReview,closePeriod,createNextPeriod,resetUserState,save});
})();
