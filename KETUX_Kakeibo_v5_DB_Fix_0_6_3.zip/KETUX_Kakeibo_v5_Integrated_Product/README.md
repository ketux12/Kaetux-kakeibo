# KETUX Kakeibo v5.0 — Product UI COMPLETE

Master source package before APK/Colab build.

## Product direction
- Mobile-first KETUX cinematic UI based on the supplied concept board.
- Bottom navigation: Home / Input / Activity / Finance / More.
- KETUX dark green, deep black, stone/cream palette.
- Official ledger and user checkpoint are deliberately separated.
- September 2026 remains CLOSED; October 2026 remains OPEN.
- Actual KETUX database is embedded; no dummy accounting database is introduced.

## Accounting behavior
- Double-entry journals remain the source of official balances.
- Cash (101), DANA/QRIS (102), Buffer (103) remain separate assets.
- Pending reconciliation remains outside official ledger.
- 4 Oct 2026 checkpoint Rp201.500 is displayed separately from official ledger.
- Local input transactions are stored in WebView localStorage and posted as balanced journal entries.

## Android
- applicationId: com.ketux.kakeibo
- version: 0.5.0 / versionCode 50
- minSdk 23 / targetSdk 35
- Java 17 / AGP 8.7.3
- Launcher icon includes KETUX mark and Android 8+ adaptive icon resource.

Build from `android/`. Colab packaging/build comes only after this source package is accepted as the master.
