# KETUX Kakeibo v5 — Stage 10 Release Checklist

## P0 — accounting safety
- [ ] September source data unchanged
- [ ] Trial balance balanced
- [ ] Pending Oct reconciliation still blocks closing
- [ ] Correction preserves audit history
- [ ] Closed periods cannot be silently edited
- [ ] Opening balance survives reload

## P0 — persistence/security
- [ ] Input survives process/app restart
- [ ] PIN works
- [ ] Auto-lock works
- [ ] Backup excludes PIN
- [ ] Restore works with compatible backup
- [ ] Incompatible account structure is rejected

## P1 — daily UX
- [ ] Quick input
- [ ] Repeat last
- [ ] Game Session
- [ ] Transfer + Admin
- [ ] Daily Close
- [ ] Search/filter

## P1 — reporting/data
- [ ] Reports
- [ ] Journal CSV
- [ ] Trial Balance CSV
- [ ] Print/PDF
- [ ] CSV/XLSX import
- [ ] Duplicate review
- [ ] AI draft confirmation

## P1 — mobile shell
- [ ] Launch
- [ ] Back navigation
- [ ] Background/foreground
- [ ] Activity recreation
- [ ] Android 11 WebView
- [ ] No unexpected external file access

## P2 — product polish
- [ ] Goals
- [ ] Wants Budget
- [ ] Insights
- [ ] Weekly Reflection
- [ ] Monthly Review
