# KETUX Kakeibo 0.6.1 — Database Asset Loading Fix

The Android shell now serves `assets/` through the virtual HTTPS origin:

`https://appassets.androidplatform.net/assets/index.html`

`MainActivity` intercepts only requests for that host and `/assets/` path and reads the matching packaged asset directly from `AssetManager`.

This keeps:
- `setAllowFileAccess(false)`
- `setAllowContentAccess(false)`
- `setAllowFileAccessFromFileURLs(false)`
- `setAllowUniversalAccessFromFileURLs(false)`

No AndroidX/WebKit dependency was added.

`index.html` remains unchanged, so its existing:

`fetch('ketux_database.json')`

resolves against the HTTPS virtual asset origin and can load the packaged JSON.

Release version:
- versionCode: 61
- versionName: 0.6.1
