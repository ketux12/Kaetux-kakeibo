import json
from pathlib import Path
d=json.loads(Path(__file__).parents[1].joinpath("ketux_database.json").read_text())
assert d["period_management"]["periods"][0]["status"]=="closed"
assert d["period_management"]["periods"][1]["status"]=="open"
for j in d["journals"]:
    assert sum(x["debit"] for x in j["lines"])==sum(x["credit"] for x in j["lines"])
# source September checkpoints
cp={x["id"]:x for x in d["reconciliation"]["checkpoints"]}
assert cp["cp-2026-09-30"]["total"]==154500
assert cp["cp-2026-10-01"]["total"]==121500
assert cp["cp-2026-10-04-user"]["total"]==201500
print("PASS: source database invariants")
