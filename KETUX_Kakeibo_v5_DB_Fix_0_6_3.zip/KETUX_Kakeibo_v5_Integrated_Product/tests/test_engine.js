const fs=require('fs'),vm=require('vm');
const db=JSON.parse(fs.readFileSync(__dirname+'/../ketux_database.json','utf8'));
let store={}; const ctx={window:{},localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v},console}; vm.createContext(ctx);
vm.runInContext(fs.readFileSync(__dirname+'/../engine.js','utf8'),ctx); const K=ctx.window.KETUX; K.init(db);
function assert(c,m){if(!c)throw new Error('FAIL: '+m)}
let sep=K.assetBalances('2026-09','2026-09-30'); assert(sep.total===154500,'Sep assets');
let sei=K.incomeExpense('2026-09','2026-09-30'); assert(sei.income===1503000 && sei.expense===1348500 && sei.net===154500,'Sep P&L');
let oct=K.assetBalances('2026-10','2026-10-01'); let oct5=K.assetBalances('2026-10','2026-10-05'); assert(oct5[101]===28000&&oct5[102]===0&&oct5[103]===150000&&oct5.total===178000,'Oct 5 assets'); assert(oct[101]===16500&&oct[102]===0&&oct[103]===0&&oct.total===16500,'Oct 1 assets');
assert(K.trial('2026-09','2026-09-30').balanced,'Sep trial balance'); assert(K.trial('2026-10','2026-10-01').balanced,'Oct trial balance');
assert(K.allPosted().length===171,'source journal count'); assert(K.allPosted().every(j=>K.journalBalance(j).balanced),'all source journals balanced');
try{K.post({date:'2026-10-04',period_id:'2026-09',description:'closed',lines:[{account:'101',debit:1,credit:0},{account:'502',debit:0,credit:1}]});throw new Error('closed period accepted');}catch(e){assert(e.message.includes('CLOSED'),'closed period guard');}
K.post({date:'2026-10-04',time:'10:00',period_id:'2026-10',description:'test expense',lines:[{account:'502',debit:1000,credit:0},{account:'101',debit:0,credit:1000}]});
assert(K.allPosted().length===172,'user posting appended');
console.log('PASS: KETUX v5 integrated engine tests');
const ai=K.aiDraft('beli kopi 8 ribu cash hari ini'); assert(ai.amount===8000 && ai.source==='AI','AI draft parse'); assert(ai.description.includes('kopi'),'AI description');
const ds=K.addImportDrafts([{date:'2026-10-04',time:'12:00',amount:8000,description:'Import kopi',kind:'expense',account:'503',wallet:'101'}],{source:'Import'}); assert(ds.length===1 && K.importDrafts().length===1,'import draft created');
K.confirmImportDraft(ds[0].id,{force_duplicate:true}); assert(K.importDrafts().length===0,'import draft confirmed'); assert(K.allPosted().some(j=>j.description==='Import kopi'&&j.source==='Import'),'import posted');
console.log('PASS: Stage 4 import/AI engine tests');
const intel=K.intelligence('2026-10','2026-10-04'); assert(intel.metrics.income>=0 && Array.isArray(intel.insights),'intelligence snapshot');
const refl=K.weeklyReflection('2026-10','2026-10-04'); assert(refl.start==='2026-09-28' && refl.end==='2026-10-04' && refl.questions.length===4,'weekly reflection');
const adv=K.advisorSnapshot('2026-10','2026-10-04'); assert(adv.disclaimer && adv.metrics.net===intel.metrics.net,'advisor uses engine metrics');
console.log('PASS: Stage 5 intelligence tests');
const cross=K.weeklyReflectionAll('2026-10-04'); assert(cross.start==='2026-09-28' && cross.end==='2026-10-04','cross-period weekly window'); assert(cross.income>0,'cross-period weekly income');
const g=K.addGoal({name:'Test Buffer Goal',targetAmount:200000,deadline:'2026-12-31',sourceAccount:'103'}); const gs=K.goalSnapshot('2026-10-04').find(x=>x.id===g.id); assert(gs && gs.progress===150000,'goal derives real buffer balance'); K.removeGoal(g.id);
const b=K.addBudget({type:'wants',amount:50000,startDate:'2026-10-01',endDate:'2026-10-31',label:'Test Wants'}); const wb=K.wantsBudgetSnapshot('2026-10-01','2026-10-31'); assert(wb.budget===50000 && wb.source==='configured','configured Wants budget'); K.removeBudget(b.id);
const mr=K.monthlyReview('2026-10'); assert(mr.month==='2026-10' && mr.wants>=0 && Array.isArray(mr.questions),'monthly review');
try{K.post({date:'2026-10-04',time:'20:00',period_id:'2026-10',description:'illegal buffer game',lines:[{account:'501',debit:10000,credit:0},{account:'103',debit:0,credit:10000}]});throw new Error('buffer game guard failed');}catch(e){assert(e.message.includes('Buffer tidak boleh digunakan'),'buffer cannot fund game');}
console.log('PASS: Stage 6 personal finance expansion tests');
const sec0=K.securityStatus(); assert(sec0.pinEnabled===false,'PIN default disabled'); assert(sec0.nativeBiometricReady===false,'biometric is not falsely claimed ready');
const cfg=K.setSecurityConfig({pinEnabled:true,pinHash:'test-hash',autoLockMinutes:5}); assert(cfg.pinEnabled===true&&cfg.autoLockMinutes===5,'security config');
const integ=K.integrityCheck(); assert(integ.ok===true,'integrity check passes on balanced journals'); assert(integ.journalCount===K.allPosted().length,'integrity journal count');
const bp=K.backupPayload(); assert(bp.backup_version==='6.0-stage9','stage7 backup version'); assert(bp.user_state.settings.pinHash===null && bp.user_state.settings.pinEnabled===false,'backup excludes device PIN');
K.recordSecurityEvent('TEST','security event'); assert(K.securityEvents().some(x=>x.action==='TEST'),'security event recorded');
console.log('PASS: Stage 7 security/reliability tests');
assert(K.productionDiagnostics().ok===true,'production diagnostics');
assert(K.state().schema_version===8,'state schema version');
const bp8=K.backupPayload(); assert(bp8.backup_version==='6.0-stage9','stage9 backup version');
const before=JSON.stringify(K.state()); K.restorePayload(bp8); assert(K.securityStatus().pinEnabled===false,'restore strips device PIN');
console.log('PASS: Stage 8 polish/production reliability tests');

// Stage 9 — release candidate integration hardening
// Stage 9 — release candidate integration hardening
const corrTarget=K.allPosted().find(j=>j.period_id==='2026-10' && j.description==='test expense');
const replacement={date:'2026-10-04',time:'10:30',description:'test expense corrected',reason:'RC correction',lines:[{account:'502',debit:1200,credit:0},{account:'101',debit:0,credit:1200}]};
K.correctJournal(corrTarget.id,replacement);
assert(!K.allPosted().some(j=>j.id===corrTarget.id),'corrected original is excluded from effective ledger');
assert(K.allPosted().some(j=>j.description==='test expense corrected'),'replacement is effective');
assert(K.correctionRecords().some(c=>c.original_id===corrTarget.id),'correction audit record exists');
assert(K.integrityCheck().ok===true,'integrity survives correction');
K.addPending({id:'test-pending',status:'pending',reason:'test',checkpoint_target:{total:0}});
try{K.closePeriod('2026-10');throw new Error('pending period closed unexpectedly');}catch(e){assert(e.message.includes('pending reconciliation'),'pending reconciliation blocks close');}
// A clean fixture verifies period close/opening persistence independently of the unresolved source reconciliation trail.
const cleanDb=JSON.parse(JSON.stringify(db)); cleanDb.pending_reconciliation=[];
const cleanCtx={window:{},localStorage:{getItem:k=>null,setItem:(k,v)=>{}},console}; vm.createContext(cleanCtx);
vm.runInContext(fs.readFileSync(__dirname+'/../engine.js','utf8'),cleanCtx); const KC=cleanCtx.window.KETUX; KC.init(cleanDb);
const closedOct=KC.closePeriod('2026-10');
assert(closedOct.status==='closed','period closes after reconciliation is clear');
assert(KC.period('2026-10').status==='closed','closed period persists in effective period state');
const np=KC.createNextPeriod('2026-10','2026-11-01');
assert(np.id==='2026-11' && KC.currentPeriod().id==='2026-11','next period created and selected');
assert(KC.period('2026-11').opening_assets[101]===closedOct.closing_assets[101],'opening cash carries forward');
assert(KC.state().periodOverrides['2026-10'].status==='closed' && KC.state().periodOverrides['2026-11'].status==='open','period state persisted outside source DB');
const savedState=JSON.stringify(KC.state());
const freshCtx={window:{},localStorage:{getItem:k=>savedState,setItem:(k,v)=>{}},console}; vm.createContext(freshCtx);
vm.runInContext(fs.readFileSync(__dirname+'/../engine.js','utf8'),freshCtx); const KF=freshCtx.window.KETUX; KF.init(cleanDb);
assert(KF.period('2026-10').status==='closed' && KF.period('2026-11').status==='open','period overrides survive reload');
assert(KF.currentPeriod().id==='2026-11','current period survives reload');
assert(KF.assetBalances('2026-11','2026-11-01').total===closedOct.closing_total,'opening balance survives period reload');
console.log('PASS: Stage 9 release-candidate integration tests');
