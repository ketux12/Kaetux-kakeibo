# KETUX Kakeibo v5.1 — Integrated Product

This build combines the v5 Product UI with a deterministic accounting engine backed by the KETUX source database.

## Core flows
- Source journals remain immutable reference data.
- User-posted journals are appended to localStorage and must balance debit=credit.
- Period status is enforced: closed periods reject new postings.
- Opening assets/equity are included in period ledger calculations.
- Cash, DANA, and Buffer remain separate asset accounts.
- Income/expense reports are derived from journal lines and account types.
- Trial balance is calculated from opening balances + posted journal movements.
- Reconciliation pending items remain excluded from official balances.
- The 4 Oct 2026 user checkpoint remains a checkpoint, not a ledger rewrite.
- Transaction date/time and created_at are retained for audit.

## Important
This is build-ready source, not a claim of final production readiness. Device testing and accounting test cases are still required before release.
